# control_cmd.py �����н�


def cmd_stop():
    print("stop")
    pass


def cmd_start():
    print("start")
    pass


# ����
def cmd_shift():
    print("shift")
    pass


# ����
def cmd_ctrl():
    print("ctrl")
    pass


def cmd_left():
    print("left")
    pass


def cmd_right():
    print("right")
    pass


def cmd_up():
    print("up")
    pass


def cmd_down():
    print("down")
    pass


def cmd_e():
    print("e")
    pass


def cmd_q():
    print("q")
    pass


switch_cmd = {
    "stop": cmd_stop,
    "start": cmd_start,
    "shift": cmd_shift,
    "ctrl": cmd_ctrl,
    "right": cmd_right,
    "left": cmd_left,
    "up": cmd_up,
    "down": cmd_down,
    "e": cmd_e,
    "q": cmd_q,
}
