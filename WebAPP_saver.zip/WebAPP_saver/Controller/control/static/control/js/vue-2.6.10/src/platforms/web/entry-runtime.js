/* @flow */

import Vue from './runtime'

export default Vue
