class OpInfor:
    def __init__(self):
        self.op = ""
        self.person = "admin"
        self.date = ""
        self.error = ""

    def get_map(self):
        custom_map = {"op": self.op, "person": self.person, "date": self.date, "error": self.error}
        return custom_map
