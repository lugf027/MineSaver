from django.apps import AppConfig


class ControlConfig(AppConfig):
    name = 'control'
